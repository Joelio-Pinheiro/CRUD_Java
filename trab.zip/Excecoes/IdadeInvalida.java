package Excecoes;

public class IdadeInvalida extends Exception{
    public IdadeInvalida(String errorMessage){
        super(errorMessage);
    }
}